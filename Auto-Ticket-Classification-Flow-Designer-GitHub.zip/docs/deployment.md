# Deployment Guide

## Before Deployment
1. Complete all tests.
2. Verify the Flow is inactive during development.
3. Ensure the correct Update Set is current.
4. Review permissions and roles.
5. Confirm notification configuration.

## Deployment
1. Activate the completed Flow.
2. Complete testing in the target instance.
3. Capture the Update Set.
4. Commit/export the Update Set as required by the ServiceNow environment.
5. Validate the Flow after deployment.

## Security Notes
- Only authorized ServiceNow users should modify the Flow.
- Restrict administrative access.
- Avoid storing passwords or sensitive personal information in the repository.
- Do not upload ServiceNow instance credentials, API keys, or tokens to GitHub.
