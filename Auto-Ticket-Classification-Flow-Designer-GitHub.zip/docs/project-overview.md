# Project Overview

## Title
Auto Ticket Classification using Flow Designer

## Domain
ServiceNow / IT Service Management / Workflow Automation

## Objective
To automatically classify IT helpdesk tickets according to their issue description and update the relevant category and subcategory.

## Existing System
Tickets are manually reviewed by IT support staff.

### Problems
- Time consuming
- Human errors
- Inconsistent classification
- Difficult to scale

## Proposed System
A ServiceNow Flow Designer workflow automatically analyzes ticket information and updates classification fields.

## Main Actors
- Caller / Student
- Teacher
- IT Helpdesk Staff
- ServiceNow Administrator

## Input
- Short description
- Description
- Caller details
- Ticket number

## Output
- Category
- Subcategory
- Notification
- Updated ticket status/details
