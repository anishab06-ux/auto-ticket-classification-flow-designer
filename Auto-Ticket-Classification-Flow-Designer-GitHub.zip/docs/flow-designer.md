# Flow Designer Configuration

## Flow Name
Auto Ticket Classification

## Trigger
When an Incident record is created.

## Data Pills
Use:
- Trigger -> Incident -> Short description
- Trigger -> Incident -> Description
- Trigger -> Incident -> Number
- Trigger -> Incident -> Caller

## Classification Rules

### Rule 1 - Network
Keywords:
- wifi
- wi-fi
- network
- internet

Result:
- Category: Network
- Subcategory: Wi-Fi

### Rule 2 - Hardware
Keywords:
- laptop
- computer
- desktop

Result:
- Category: Hardware
- Subcategory: Laptop

### Rule 3 - Login
Keywords:
- login
- password
- sign in
- account

Result:
- Category: Software
- Subcategory: Login

### Rule 4 - Performance
Keywords:
- slow
- performance
- hanging

Result:
- Category: Performance
- Subcategory: Slow System

### Rule 5 - Printer
Keywords:
- printer
- printing

Result:
- Category: Hardware
- Subcategory: Printer

### Default Rule
If no keyword matches:
- Category: General
- Subcategory: Other

## Final Flow

Trigger
-> Read Incident
-> If/Else Classification
-> Update Incident
-> Send Email
-> End
