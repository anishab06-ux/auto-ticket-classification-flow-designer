# ServiceNow Setup Guide

## 1. Create an Update Set
Navigate to:

System Update Sets -> Local Update Sets -> New

Suggested name:

`Auto Ticket Classification - Flow Designer`

Save and make the Update Set current.

## 2. Open Flow Designer
Navigate to:

All -> Flow Designer

Create a new Flow.

Suggested name:

`Auto Ticket Classification`

## 3. Configure Trigger
Use an Incident record trigger.

Example:
- Table: Incident
- Trigger: Created

## 4. Add Classification Logic
Use Flow Designer If/Else or Decision logic.

Check the Short Description and Description fields.

## 5. Update Record
Use the Update Record action to set:
- Category
- Subcategory

## 6. Email Notification
Add an email action after successful classification.

Example subject:

`Ticket ${Number} Classified Successfully`

## 7. Test
Create sample incidents and verify that the expected category and subcategory are populated.
