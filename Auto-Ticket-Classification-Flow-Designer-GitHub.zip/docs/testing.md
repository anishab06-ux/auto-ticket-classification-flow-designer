# Testing and Validation

## Test Case 1
Input:
`Wi-Fi is not connecting in the classroom`

Expected:
- Category: Network
- Subcategory: Wi-Fi

## Test Case 2
Input:
`My laptop is not starting`

Expected:
- Category: Hardware
- Subcategory: Laptop

## Test Case 3
Input:
`I forgot my login password`

Expected:
- Category: Software
- Subcategory: Login

## Test Case 4
Input:
`The computer is very slow`

Expected:
- Category: Performance
- Subcategory: Slow System

## Test Case 5
Input:
`Printer is not printing`

Expected:
- Category: Hardware
- Subcategory: Printer

## Test Case 6
Input:
`Projector issue in classroom`

Expected:
- Category: General
- Subcategory: Other

## Validation Checklist
- [ ] Flow activates successfully
- [ ] Trigger works for new incidents
- [ ] Classification rules work
- [ ] Category updates correctly
- [ ] Subcategory updates correctly
- [ ] Email notification is generated
- [ ] Unknown issues use default classification
