# Auto Ticket Classification using Flow Designer

## Project Overview
The **Auto Ticket Classification using Flow Designer** project automates the classification of IT helpdesk tickets in ServiceNow.

The school IT helpdesk receives many support requests from students and teachers. Manually identifying the issue type, category, subcategory, and notifying the caller is time-consuming and error-prone.

This project uses **ServiceNow Flow Designer** to automate the ticket classification workflow.

## Problem Statement
IT staff manually review every ticket to:
- Identify the issue type
- Select the correct category and subcategory
- Inform the caller about ticket creation

This process becomes difficult when the number of requests increases.

## Proposed Solution
The system automatically:
1. Detects a newly created incident/ticket.
2. Reads the ticket description and short description.
3. Classifies the ticket based on predefined conditions.
4. Updates the appropriate category and subcategory.
5. Sends an email notification to the caller.
6. Maintains a consistent and scalable classification process.

## Technology Used
- ServiceNow
- Flow Designer
- Incident Management
- Update Sets
- Email Notifications
- ServiceNow Tables and Fields

## Example Classification

| Ticket Description | Category | Subcategory |
|---|---|---|
| Wi-Fi is not connecting | Network | Wi-Fi |
| Laptop is not starting | Hardware | Laptop |
| Cannot login to account | Software | Login |
| System is very slow | Performance | Slow System |
| Printer is not working | Hardware | Printer |

## Project Workflow

```text
New Ticket Created
        |
        v
Read Ticket Details
        |
        v
Identify Issue Type
        |
        v
Check Classification Conditions
        |
        v
Update Category/Subcategory
        |
        v
Send Email Notification
        |
        v
Ticket Classified Successfully
```

## ServiceNow Implementation
The project is implemented using Flow Designer.

### Flow Trigger
**When:** An incident/ticket is created.

### Flow Actions
1. Get ticket details.
2. Evaluate ticket description.
3. Use If/Else conditions for classification.
4. Update Category.
5. Update Subcategory.
6. Send notification email.
7. Log/update the ticket.

## Suggested Flow Logic

```text
IF description contains "wifi" OR "network"
    Category = Network
    Subcategory = Wi-Fi

ELSE IF description contains "laptop" OR "computer"
    Category = Hardware
    Subcategory = Laptop

ELSE IF description contains "login" OR "password"
    Category = Software
    Subcategory = Login

ELSE IF description contains "slow" OR "performance"
    Category = Performance
    Subcategory = Slow System

ELSE IF description contains "printer"
    Category = Hardware
    Subcategory = Printer

ELSE
    Category = General
    Subcategory = Other
```

## Milestones

### Milestone 1 - Requirement Analysis & Planning
- Business use case
- Create new Update Set
- Navigate to Picture View
- Identify fields and classification rules

### Milestone 2 - Backend Development & Configuration
- Configure incident fields
- Define categories and subcategories
- Prepare classification conditions

### Milestone 3 - Automation using Flow Designer & Email Notification
- Create Flow
- Configure trigger
- Add classification logic
- Update ticket fields
- Configure email notification

### Milestone 4 - Testing, Validation & Security
- Test different ticket types
- Validate category/subcategory
- Test email notifications
- Check permissions and access

### Milestone 5 - Deployment & Conclusion
- Activate flow
- Test in target environment
- Document results
- Prepare final project report

## Testing Scenarios

| Test Case | Input | Expected Result |
|---|---|---|
| TC01 | Wi-Fi not working | Network / Wi-Fi |
| TC02 | Laptop not starting | Hardware / Laptop |
| TC03 | Cannot login | Software / Login |
| TC04 | Computer is slow | Performance / Slow System |
| TC05 | Printer not working | Hardware / Printer |
| TC06 | Unknown issue | General / Other |

## Benefits
- Reduces manual work
- Improves ticket classification accuracy
- Saves IT support time
- Provides consistent categorization
- Automatically notifies users
- Scales better for large numbers of tickets

## Repository Structure

```text
auto-ticket-classification-flow-designer/
├── README.md
├── docs/
│   ├── project-overview.md
│   ├── servicenow-setup.md
│   ├── flow-designer.md
│   ├── testing.md
│   └── deployment.md
├── sample-data/
│   └── sample_tickets.csv
├── flow/
│   └── classification-rules.json
├── .gitignore
└── LICENSE
```

## Conclusion
The project demonstrates how ServiceNow Flow Designer can automate IT helpdesk ticket classification and notification. It provides a simple, scalable workflow for reducing manual classification effort.
